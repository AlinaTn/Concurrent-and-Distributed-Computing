<?php
require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/env.php';
use Google\Cloud\Storage\StorageClient;
$app = array();
$app['bucket_name'] = "myclouda.appspot.com";
$app['mysql_user'] = "root";
$app['mysql_password'] = "test";
$app['mysql_dbname'] = "testdb";
$app['project_id'] = getenv('GCLOUD_PROJECT');

function upload_object($bucketName, $objectName, $source)
{
    $storage = new StorageClient();
    $file = fopen($source, 'r');
    $bucket = $storage->bucket($bucketName);
    $object = $bucket->upload($file, [
        'name' => $objectName
    ]);
    printf('Uploaded %s to gs://%s/%s' . PHP_EOL, basename($source), $bucketName, $objectName);
}
if ($_FILES) {
	if ($_FILES["uploaded_files"]["error"] > 0) {
		echo "Error: " . $_FILES["uploaded_files"]["error"] . "<br />";
	} elseif ($_FILES["uploaded_files"]["type"] !== "text/plain") {
		echo "File must be a .txt";
	} else {
		$file_handle = fopen($_FILES['uploaded_files']['tmp_name'], 'r');
		upload_object($app['bucket_name'],
						$_FILES['uploaded_files']['name'],
						$_FILES['uploaded_files']['tmp_name']
					);
		var_dump($_FILES);
		echo "\n\n";
		var_dump($file_handle);
	}
}
$servername = null;
$username = $app['mysql_user'];
$password = $app['mysql_password'];
$dbname = $app['mysql_dbname'];
$dbport = null;
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, 
	$dbport, "/cloudsql/myclouda:europe-west1:test");
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "\nConnected successfully\n";
echo "\ntesting cloud app\n";
?>
<form action="index.php" enctype="multipart/form-data" method="post">
    Files to upload: <br>
   <input type="file" name="uploaded_files" size="40">
   <input type="submit" value="Send">
</form>
